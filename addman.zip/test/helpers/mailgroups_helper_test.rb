require 'test_helper'

class MailgroupsHelperTest < ActionView::TestCase
end
