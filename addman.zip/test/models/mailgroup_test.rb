require 'test_helper'

class MailgroupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
