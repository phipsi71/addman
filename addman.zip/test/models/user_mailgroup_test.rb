require 'test_helper'

class UserMailgroupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
