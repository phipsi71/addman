class Salutation < ActiveRecord::Base
end
