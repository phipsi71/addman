(function() {
  $(function() {
    return $('[data-toggle="tooltip"]').tooltip();
  });

}).call(this);
