(function() {
  $(function() {
    $('.close-modal').click(function() {
      $('#mailgroupwarn').modal('hide');
    });
  });

}).call(this);
