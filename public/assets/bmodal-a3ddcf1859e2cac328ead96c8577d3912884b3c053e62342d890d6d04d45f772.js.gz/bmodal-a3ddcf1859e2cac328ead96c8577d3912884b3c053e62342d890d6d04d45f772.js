(function() {
  $.fn.twitter_bootstrap_confirmbox.defaults = {
    fade: false,
    title: "Please confirm",
    cancel: "Cancel",
    cancel_class: "btn cancel",
    proceed: "OK",
    proceed_class: "btn proceed btn-primary"
  };

}).call(this);
